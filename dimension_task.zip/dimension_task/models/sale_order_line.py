# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    dimension = fields.Char(string='Dimension')


    def _prepare_invoice_line(self, **optional_values):
        res = super(SaleOrderLine, self)._prepare_invoice_line()
        res.update({'dimension_invoice': self.dimension})
        return res

    # def _prepare_procurement_values(self, group_id=False):
    #     res = super(SaleOrderLine, self)._prepare_procurement_values(group_id)
    #     res.update({'dimension_stock': self.dimension})
    #     return res
    #


# class StockRule(models.Model):
#     _inherit = 'stock.rule'
#
#     def _get_stock_move_values(self, product_id, product_qty, product_uom, location_id, name, origin, values, group_id):
#         res = super(StockRule, self)._get_stock_move_values(product_id, product_qty, product_uom, location_id,
#                                                             name, origin, values, group_id)
#         res['dimension_stock'] = values.get('dimension_stock', False)
#         return res


# class Stockmove(models.Model):
#     _inherit = 'stock.move'
#
#     product_id = fields.Many2one('product.product')
#     # move_id = fields.Many2one('stock.picking')
#     dimension_line = fields.Char(related='product_id.dimension', string='Dimension')


# class StockPicking(models.Model):
#     _inherit = 'stock.picking'
#
#     product_id = fields.Many2one('product.product')
#     dimension_stock_picking = fields.Char(compute='_compute_dimension', string='Dimension', readonly=False)
#
#     @api.depends("product_id")
#     def _compute_dimension(self):
#         for record in self:
#             record.dimension_stock_picking = record.product_id.dimension
#


class ProductProduct(models.Model):
    _inherit = 'product.product'

    dimension = fields.Char(string='Dimension')
