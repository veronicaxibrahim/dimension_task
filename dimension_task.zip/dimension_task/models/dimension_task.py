# -*- coding: utf-8 -*-

from odoo import models, fields, api


class SaleOrderLine(models.Model):
    _inherit = 'sale.order.line'

    product_id = fields.Many2one('product.product')
    dimension = fields.Char(related='product_id.dimension',readonly=True)

class Stockmove(models.Model):
    _inherit = 'stock.move'

    product_id = fields.Many2one('product.product')
    dimension_stock = fields.Char(related='product_id.dimension',string='Dimension',readonly=False)

class ProductProduct(models.Model):
    _inherit = 'product.product'

    dimension = fields.Char(string='Dimension')