# -*- coding: utf-8 -*-

from odoo import models, fields, api



class StockMove(models.Model):
    _inherit = 'stock.move'

    dimension_stock = fields.Char(string='Dimension')
    # sale_id = fields.Many2one('procurement.group')

