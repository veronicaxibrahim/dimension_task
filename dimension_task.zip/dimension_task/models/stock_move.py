# -*- coding: utf-8 -*-

from odoo import models, fields, api



class StockMove(models.Model):
    _inherit = 'stock.move'

    dimension_stock = fields.Char(string='Dimension')
    sale_id = fields.Many2one('procurement.group')


    def _get_new_picking_values(self):
        res = super(StockMove, self)._get_new_picking_values()
        # Pass value of note field from Sales Order to Picking
        res.update({'dimension_stock': self.group_id.sale_id.dimension})
        return res
